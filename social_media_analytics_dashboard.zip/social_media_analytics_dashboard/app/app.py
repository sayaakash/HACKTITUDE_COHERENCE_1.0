# app.py
from flask import Flask, render_template, request
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

class SocialMediaPlatform:
    def __init__(self, name, users, competitors):
        self.name = name
        self.users = users
        self.competitors = competitors
        self.competitor_data = {}

    def authenticate(self, username, password):
        if username in self.users and self.users[username]['password'] == password:
            return True
        else:
            return False

    def get_user_data(self, username):
        if username in self.users:
            return self.users[username]['data']
        else:
            return None

    def generate_analytics(self, username):
        user_data = self.get_user_data(username)
        if user_data:
            age = user_data['age']
            followers = [age * 10, age * 15, age * 20, age * 25]  
            engagement_rate = [0.5, 0.6, 0.7, 0.8]  

            plot_url = self.plot_metrics_over_time(followers, engagement_rate)

            future_time, future_followers, future_engagement_rate = self.predict_future_metrics(followers, engagement_rate)

            future_followers_plot_url = self.plot_future_metrics(future_time, future_followers, 'Followers Projection')
            future_engagement_plot_url = self.plot_future_metrics(future_time, future_engagement_rate, 'Engagement Rate Projection')

            return followers, engagement_rate, future_time, future_followers, future_engagement_rate, plot_url, future_followers_plot_url, future_engagement_plot_url

    def plot_metrics_over_time(self, followers, engagement_rate):
        plt.figure(figsize=(10, 6))
        plt.subplot(2, 1, 1)
        plt.plot(range(1, 5), followers, marker='o', linestyle='-')
        plt.title(f"{self.name} - Followers Over Time")
        plt.xlabel("Time")
        plt.ylabel("Followers")
        plt.subplot(2, 1, 2)
        plt.plot(range(1, 5), engagement_rate, marker='o', linestyle='-')
        plt.title(f"{self.name} - Engagement Rate Over Time")
        plt.xlabel("Time")
        plt.ylabel("Engagement Rate")

        plt.tight_layout()
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.close()
        return plot_url

    def predict_future_metrics(self, followers, engagement_rate):
        X = np.array(range(1, 5)).reshape(-1, 1)  
        y_followers = np.array(followers)
        y_engagement_rate = np.array(engagement_rate)

        follower_model = LinearRegression()
        follower_model.fit(X, y_followers)

        engagement_model = LinearRegression()
        engagement_model.fit(X, y_engagement_rate)

        future_time = np.array([5, 6, 7, 8]).reshape(-1, 1)  
        future_followers = follower_model.predict(future_time)
        future_engagement_rate = engagement_model.predict(future_time)

        return future_time, future_followers, future_engagement_rate

    def plot_future_metrics(self, future_time, data, title):
        plt.figure(figsize=(6, 4))
        plt.plot(future_time, data, marker='o', linestyle='-')
        plt.title(f"{self.name} - {title}")
        plt.xlabel("Time")
        plt.ylabel(title)
        plt.grid(True)

        plt.tight_layout()
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.close()
        return plot_url

    def generate_post_suggestions(self, user_data):
        user_interests = user_data.get('interests', [])
        followers_demographics = self.analyze_followers_demographics()
        competitor_activities = self.analyze_competitor_activities()

        suggestions = []

        for interest in user_interests:
            suggestions.append(f"Post about {interest}")

        if followers_demographics:
            suggestions.append("Post content relevant to your follower demographics")

        if competitor_activities:
            suggestions.append("Emulate successful strategies of competitors")

        return suggestions

    def analyze_followers_demographics(self):
        return {"age_range": "18-35", "location": "United States"}

    def analyze_competitor_activities(self):
        return {"most_engaging_post": "Photo posts with captions", "popular_hashtags": ["#trendy", "#inspiration"]}

    def analyze_competitors(self):
        for comp_name, comp_data in self.competitors.items():
            activities = comp_data.get('activities', [])
            audience_interactions = self.analyze_audience_interactions(comp_name)
            self.competitor_data[comp_name] = {'activities': activities, 'audience_interactions': audience_interactions}

    def analyze_audience_interactions(self, competitor_name):
        return {'likes': 1000, 'comments': 500, 'shares': 200}

facebook_users = {
    'user1': {'password': 'pass123', 'data': {'name': 'User One', 'age': 25, 'email': 'user1@example.com', 'interests': ['Travel', 'Photography']}},
    'user2': {'password': 'pass456', 'data': {'name': 'User Two', 'age': 30, 'email': 'user2@example.com', 'interests': ['Food', 'Fitness']}}
}

twitter_users = {
    'user5': {'password': 'pass111', 'data': {'name': 'User Five', 'age': 45, 'email': 'user5@example.com', 'interests': ['Sports', 'Books']}},
    'user6': {'password': 'pass222', 'data': {'name': 'User Six', 'age': 50, 'email': 'user6@example.com', 'interests': ['Cooking', 'Gardening']}}
}

instagram_users = {
    'user7': {'password': 'pass333', 'data': {'name': 'User Seven', 'age': 55, 'email': 'user7@example.com', 'interests': ['Fashion', 'Travel']}},
    'user8': {'password': 'pass444', 'data': {'name': 'User Eight', 'age': 60, 'email': 'user8@example.com', 'interests': ['Fitness', 'Health']}}
}

linkedin_users = {
    'user9': {'password': 'pass555', 'data': {'name': 'User Nine', 'age': 35, 'email': 'user9@example.com', 'interests': ['Business', 'Networking']}},
    'user10': {'password': 'pass666', 'data': {'name': 'User Ten', 'age': 40, 'email': 'user10@example.com', 'interests': ['Career', 'Professional Development']}}
}

competitors = {
    'comp1':  {'name': 'Competitor One', 'activities':  ['Photo posts with captions', 'Videos with engaging content']},
    'comp2': {'name': 'Competitor Two', 'activities': ['Interactive polls', 'Live Q&A sessions']}
}

facebook = SocialMediaPlatform("Facebook", facebook_users, competitors)
twitter = SocialMediaPlatform("Twitter", twitter_users, competitors)
instagram = SocialMediaPlatform("Instagram", instagram_users, competitors)
linkedin = SocialMediaPlatform("LinkedIn", linkedin_users, competitors)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    platform = request.form['platform']

    if platform.lower() == "facebook":
        social_media = facebook
    elif platform.lower() == "twitter":
        social_media = twitter
    elif platform.lower() == "instagram":
        social_media = instagram
    elif platform.lower() == "linkedin":
        social_media = linkedin
    else:
        return "Invalid platform selected."

    if social_media.authenticate(username, password):
        user_data = social_media.get_user_data(username)
        if user_data:
            followers, engagement_rate, future_time, future_followers, future_engagement_rate, plot_url, future_followers_plot_url, future_engagement_plot_url = social_media.generate_analytics(username)
            suggestions = social_media.generate_post_suggestions(user_data)
            return render_template('analytics.html', platform=platform, username=username, followers=followers,
                                   engagement_rate=engagement_rate, future_time=future_time,
                                   future_followers=future_followers, future_engagement_rate=future_engagement_rate,
                                   plot_url=plot_url, future_followers_plot_url=future_followers_plot_url,
                                   future_engagement_plot_url=future_engagement_plot_url, suggestions=suggestions)
        else:
            return "User data not found."
    else:
        return "Authentication failed."

if __name__ == '__main__':
    app.run(debug=True)

